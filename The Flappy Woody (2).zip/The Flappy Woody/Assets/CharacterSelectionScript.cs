using System;
using UnityEngine;
using UnityEngine.UI;

public class CharacterSelectionScript : MonoBehaviour
{
    public GameObject characterPanel; // Reference to the character selection panel
    public Sprite[] characterSprites; // Array of character sprites to choose from
    private int selectedCharacterIndex; // Index of the currently selected character

    public Button confirmButton; // Confirm button
    public Button closeButton; // Close button

    void Start()
    {
        characterPanel.SetActive(false); // Ensure the panel is hidden initially

        // Add listeners to buttons
        confirmButton.onClick.AddListener(ConfirmSelection);
        closeButton.onClick.AddListener(ClosePanel);
    }

    public void OpenPanel()
    {
        characterPanel.SetActive(true); // Show the panel
    }

    public void ClosePanel()
    {
        characterPanel.SetActive(false); // Hide the panel
    }

    public void SelectCharacter(int characterIndex)
    {
        selectedCharacterIndex = characterIndex; // Store the selected character index
    }

    public void ConfirmSelection()
    {
        // Save the selected character index to PlayerPrefs
        PlayerPrefs.SetInt("SelectedCharacter", selectedCharacterIndex);
        PlayerPrefs.Save();
        Debug.Log("Selected Character: " + selectedCharacterIndex);

        // Close the panel
        ClosePanel();
    }

    internal void SelectCharacter(GameObject characterPrefab)
    {
        throw new NotImplementedException();
    }
}