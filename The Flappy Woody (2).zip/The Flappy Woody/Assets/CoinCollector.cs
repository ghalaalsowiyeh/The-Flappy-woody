using UnityEngine;
using UnityEngine.SceneManagement; // Required for scene management

public class CoinCollector : MonoBehaviour
{
    public int coinCount = 0; // Track the number of coins collected

    void Update()
    {
        // Check if the player has collected 15 coins
        if (coinCount >= 15)
        {
            // Load the next theme based on the current scene
            LoadNextTheme();
        }
    }

    // Call this method when a coin is collected
    public void CollectCoin()
    {
        coinCount++;
        Debug.Log("Coins collected: " + coinCount);
    }

    private void LoadNextTheme()
    {
        // Get the current scene name
        string currentScene = SceneManager.GetActiveScene().name;

        // Determine the next scene to load
        string nextScene = currentScene == "theme1" ? "theme2" : "theme1";

        // Load the next scene
        SceneManager.LoadScene(nextScene);
    }
}