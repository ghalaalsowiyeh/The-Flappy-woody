using UnityEngine;

public class CoinRotation : MonoBehaviour
{
    public float rotationSpeed = 100f; // Speed of rotation

    void Start()
    {
        rotationSpeed = Random.Range(30f, 100f); // Random speed between 30 and 100
    }

    void Update()
    {
        // Rotate the coin around the Z-axis
       // transform.Rotate(0, 0, rotationSpeed * Time.deltaTime);

        //transform.Rotate(rotationSpeed * Time.deltaTime, 0, 0); // Rotate around X-axis
        transform.Rotate(0, rotationSpeed * Time.deltaTime, 0); // Rotate around Y-axis
    }


}