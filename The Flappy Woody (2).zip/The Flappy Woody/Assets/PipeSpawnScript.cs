//new

using UnityEngine;

public class PipeSpawnScript : MonoBehaviour
{
    public GameObject pipe;
    public float spawnRate; // Time between pipe spawns (adjusted based on difficulty)
    private float timer = 0;
    public float heightOffset; // Space between pipes (adjusted based on difficulty)
    public GameObject coin; // Reference to the coin prefab
    public float gapMultiplier = 1.0f; // Control the gap multiplier


    //old
    
    void Start()
    {
        // Adjust spawn rate and height offset based on difficulty
        if (GameManager.Instance != null)
        {
            if (GameManager.Instance.currentDifficulty == GameManager.Difficulty.Easy)
            {
                spawnRate = 2.5f; // Easy difficulty: slower spawn rate
                heightOffset = 12f; // Easy difficulty: more space between pipes
            }
            else if (GameManager.Instance.currentDifficulty == GameManager.Difficulty.Hard)
            {
                spawnRate = 1.5f; // Hard difficulty: faster spawn rate
                heightOffset = 30f; // Hard difficulty: less space between pipes
            }
        }
    } 

   

    void Update()
    {
        // Spawn pipes at the adjusted rate
        if (timer < spawnRate)
        {
            timer += Time.deltaTime; // Increment timer
        }
        else
        {
            spawnPipe(); // Spawn a new pipe
            timer = 0;   // Reset timer
        }
    }

    void spawnPipe()
    {
        float lowestPoint = transform.position.y - heightOffset; // Bottom of pipe range
        float highestPoint = transform.position.y + heightOffset; // Top of pipe range

        // Instantiate pipe at a random Y position within the range
        GameObject newPipe = Instantiate(pipe, new Vector3(transform.position.x, Random.Range(lowestPoint, highestPoint), 0), transform.rotation);

        // Calculate coin position
        float pipeYPosition = newPipe.transform.position.y; // Get the Y position of the newly spawned pipe

        // Place coin above or below the pipe, ensuring it's accessible
        float coinYPosition = Random.Range(pipeYPosition - heightOffset / 2f, pipeYPosition + heightOffset / 2f);
        GameObject newCoin = Instantiate(coin, new Vector3(transform.position.x, coinYPosition, 0), transform.rotation);

        // Make the coin a child of the pipe
        newCoin.transform.parent = newPipe.transform;
    }

}

   
