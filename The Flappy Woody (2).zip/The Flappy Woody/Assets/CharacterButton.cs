using UnityEngine;
using UnityEngine.UI;

public class CharacterButton : MonoBehaviour
{
    public GameObject characterPrefab; // Assign the character prefab in the Inspector
    private CharacterSelectionScript selectionScript;

    void Start()
    {
       // selectionScript = FindObjectOfType<CharacterSelectionScript>(); // Find the CharacterSelectionScript
       // Button button = GetComponent<Button>();
        //button.onClick.AddListener(OnButtonClicked);
    }

    void OnButtonClicked()
    {
        //selectionScript.SelectCharacter(characterPrefab); // Select the character prefab
    }
}