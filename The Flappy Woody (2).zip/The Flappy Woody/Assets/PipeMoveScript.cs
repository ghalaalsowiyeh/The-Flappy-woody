/*using UnityEngine;

public class PipeMoveScript : MonoBehaviour
{
    public float moveSpeed = 5;
    public float deadZone = -45;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        transform.position = transform.position + (Vector3.left * moveSpeed) * Time.deltaTime;

        if (transform.position.x < deadZone)
        {
            Debug.Log("Pipe Delets");
            Destroy(gameObject);
        }
    }
}*/


using UnityEngine;

public class PipeMoveScript : MonoBehaviour
{
    public float moveSpeed = 7f; // Increase the speed for hard difficulty
    public float deadZone = -45;

    void Start()
    {
        // Adjust speed based on difficulty
        if (GameManager.Instance != null && GameManager.Instance.currentDifficulty == GameManager.Difficulty.Hard)
        {
            moveSpeed = 10f; // Set a higher speed for hard difficulty
        }
    }

    void Update()
    {
        transform.position += Vector3.left * moveSpeed * Time.deltaTime;

        if (transform.position.x < deadZone)
        {
            Debug.Log("Pipe Deletes");
            Destroy(gameObject);
        }
    }
}