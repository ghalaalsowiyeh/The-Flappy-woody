using UnityEngine;

public class StoreButton : MonoBehaviour
{
    public CharacterSelectionScript characterSelectionScript; // Reference to the CharacterSelectionScript

    public void OnStoreButtonClicked()
    {
        characterSelectionScript.OpenPanel(); // Open the character selection panel
    }
}