using UnityEngine;
using UnityEngine.SceneManagement; // Required for scene management

public class MainMenuButton : MonoBehaviour
{
    // Method to return to the start menu
    public void ReturnToMainMenu()
    {
        // Load the start menu scene
        SceneManager.LoadScene("start menu"); // Replace "StartMenu" with your actual start menu scene name
    }
}