
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;

public class LogicScript : MonoBehaviour
{
    public int playScore;
    public Text scoreText;
    public GameObject gameOverScreen;
    public GameObject winScreen;


    public AudioClip gameOverSound;
    public AudioClip winningSound;
    private AudioSource audioSource;
    public AudioSource backgroundAudioSource;

    public int coinCount; // Counter for collected coins
    public Text coinText; // UI text to display the coin count


    //public int winningScore = 6; // Winning condition


    //new 1
    public Text finalCoinText; // UI text to display final coin count
    public Text finalPipesText; // UI text to display final pipes passed

    private float gameTime; // Timer for the game
    private bool gameIsWon; // To prevent multiple winning conditions


    //public Button nextLevelButton; // Reference to the Next Level button

    public Button buttonTheme1; // Reference to the button for Theme 1
    public Button buttonTheme2; // Reference to the button for Theme 2

    public Button playAgainButton; // Assign this in the Inspector




    //old
    /*void Start()
    {
        audioSource = GetComponent<AudioSource>();
        gameOverScreen.SetActive(false); // Ensure it's hidden at start
        coinCount = 0; // Initialize coin count
        UpdateCoinText(); // Update the coin text display
    } */

    void Start()
    {
        audioSource = GetComponent<AudioSource>();
        gameOverScreen.SetActive(false); // Ensure it's hidden at start
        coinCount = 0; // Initialize coin count
        UpdateCoinText(); // Update the coin text display
        gameTime = 0f; // Initialize game time
        gameIsWon = false; // Reset win condition


        // Assuming you have a reference to the button
        playAgainButton.onClick.AddListener(restartGame);

    }

    //neww
    void Update()
    {
        // Increment game time
        if (!gameIsWon) // Only update if the game is not already won
        {
            gameTime += Time.deltaTime;

            // Check for win condition
            if (gameTime >= 20f) // 60 seconds
            {
                WinGame();
            }
        }
    }


    /*private void WinGame()
    {
        gameIsWon = true; // Prevents further win checks
        audioSource.PlayOneShot(winningSound);
        finalCoinText.text = "Coins Collected: " + coinCount.ToString(); // Display collected coins
        finalPipesText.text = "Pipes Passed: " + playScore.ToString(); // Display pipes passed (assuming playScore represents pipes passed)
        winScreen.SetActive(true); // Show winning screen
        Time.timeScale = 0; // Pause game
    }*/

    private void WinGame()
    {
        gameIsWon = true; // Prevent further win checks
        audioSource.PlayOneShot(winningSound);
        finalCoinText.text = "Coins Collected: " + coinCount.ToString(); // Display collected coins
        finalPipesText.text = "Pipes Passed: " + playScore.ToString(); // Display pipes passed
        winScreen.SetActive(true); // Show winning screen
        Time.timeScale = 0; // Pause game

        // Check if the player has collected at least 15 coins
        if (coinCount >= 3)
        {
            buttonTheme1.gameObject.SetActive(true); // Show Theme 1 button
            buttonTheme2.gameObject.SetActive(true); // Show Theme 2 button
        }
        else
        {
            buttonTheme1.gameObject.SetActive(false); // Hide Theme 1 button
            buttonTheme2.gameObject.SetActive(false); // Hide Theme 2 button
        }

        // Setup the button listeners
        buttonTheme1.onClick.AddListener(() => LoadScene("theme1"));
        buttonTheme2.onClick.AddListener(() => LoadScene("theme2"));
    }


    //new 1
    public void addScore(int scoreToAdd)
    {
        playScore += scoreToAdd;
        scoreText.text = playScore.ToString();
        UpdateCoinText(); // Update coin text display when score is added

        /*if (playScore >= winningScore)
        {
            audioSource.PlayOneShot(winningSound);
            finalCoinText.text = "Coins Collected: " + coinCount.ToString(); // Display collected coins
            finalPipesText.text = "Pipes Passed: " + playScore.ToString(); // Display pipes passed (assuming playScore represents pipes passed)
            winScreen.SetActive(true); // Show winning screen
            Time.timeScale = 0; // Pause game
        }*/
    }





    public void restartGame()
    {
        Debug.Log("Restarting Game...");
        Time.timeScale = 1; // Resume game before restarting
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }






    public void gameOver()
    {
        if (backgroundAudioSource != null)
        {
            backgroundAudioSource.Stop(); // Stop the background music
        }

        StartCoroutine(DelayedGameOver());
    }

    private IEnumerator DelayedGameOver()
    {
        yield return new WaitForSeconds(0.5f); // Delay for 0.5 seconds (adjust as needed)
        audioSource.PlayOneShot(gameOverSound);
        gameOverScreen.SetActive(true);
        Time.timeScale = 0; // Pause game
    }

    //old
   /* public void CollectCoin()
    {
        coinCount++;
        Debug.Log("Coins collected: " + coinCount);

        // Check if the coin count has reached 15
        if (coinCount >= 15)
        {
            LoadNextTheme();
        }
    }
   */
    private void UpdateCoinText()
    {
        coinText.text = "" + coinCount.ToString(); // Update the UI text for coins
    }





    //new2
   public void CollectCoin()
    {
        coinCount++;
        Debug.Log("Coins collected: " + coinCount);

        
    }







    //new
    private void LoadNextTheme()
    {
        // Get the current scene name
        string currentScene = SceneManager.GetActiveScene().name;

        // Determine the next scene to load
        string nextScene = currentScene == "theme1" ? "theme2" : "theme1";

        // Load the next scene
        SceneManager.LoadScene(nextScene);
    }

    public void OnNextLevelButtonClicked()
    {
        LoadNextTheme(); // Call the method to load the next theme
    }

    private void LoadScene(string sceneName)
    {
        SceneManager.LoadScene(sceneName);
    }
}



