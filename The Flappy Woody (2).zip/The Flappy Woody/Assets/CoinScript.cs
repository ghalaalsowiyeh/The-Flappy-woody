using UnityEngine;
using UnityEngine.SceneManagement;

public class CoinScript : MonoBehaviour
{
    public LogicScript logic; // Reference to LogicScript for scoring

    void Start()
    {
        logic = GameObject.FindGameObjectWithTag("Logic").GetComponent<LogicScript>();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.layer == 3) // Assuming the player is on layer 3
        {
            logic.CollectCoin(); // Increment the coin count
            Destroy(gameObject); // Destroy the coin
        }

    }

   
}