using UnityEngine;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance; // Singleton instance
    public enum Difficulty { Easy, Hard } // Define difficulty levels
    public Difficulty currentDifficulty; // Store the selected difficulty

    void Awake()
    {
        // Ensure only one instance of GameManager exists
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject); // Persist between scenes
        }
        else
        {
            Destroy(gameObject);
        }
    }

    // Method to set the difficulty
    public void SetDifficulty(string difficulty)
    {
        if (difficulty == "Easy")
        {
            currentDifficulty = Difficulty.Easy;
        }
        else if (difficulty == "Hard")
        {
            currentDifficulty = Difficulty.Hard;
        }
    }


}

