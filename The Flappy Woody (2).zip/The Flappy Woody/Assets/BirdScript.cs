/*using UnityEngine;

public class BirdScript : MonoBehaviour
{
    public Rigidbody2D myRigidbody;
    public float flabStrength;
    public LogicScript logic;
    public bool birdIsAlive = true;

    public AudioClip collisionSound;
    private AudioSource audioSource;

    void Start()
    {
        logic = GameObject.FindGameObjectWithTag("Logic").GetComponent<LogicScript>();
        audioSource = GetComponent<AudioSource>();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space) && birdIsAlive)
        {
            myRigidbody.linearVelocity = Vector2.up * flabStrength;
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (birdIsAlive)
        {
            audioSource.PlayOneShot(collisionSound);
            birdIsAlive = false;
            logic.gameOver(); // Ensure this triggers correctly
        }
    }
}

*/


using UnityEngine;

public class BirdScript : MonoBehaviour
{
    public Rigidbody2D myRigidbody;
    public float flabStrength;
    public LogicScript logic;
    public bool birdIsAlive = true;

    public AudioClip collisionSound;
    private AudioSource audioSource;


    public SpriteRenderer birdSpriteRenderer; // Reference to the bird's sprite renderer
    public Sprite[] characterSprites; // Array of character sprites




    void Start()
    {

        // Get the selected character index from PlayerPrefs
        int selectedCharacterIndex = PlayerPrefs.GetInt("SelectedCharacter", 0); // Default to 0 if no selection is saved

        // Ensure the index is within bounds of the array
        if (selectedCharacterIndex >= 0 && selectedCharacterIndex < characterSprites.Length)
        {
            birdSpriteRenderer.sprite = characterSprites[selectedCharacterIndex]; // Assign the selected sprite
        }
        else
        {
            Debug.LogWarning("SelectedCharacter index is out of bounds. Defaulting to index 0.");
            birdSpriteRenderer.sprite = characterSprites[0]; // Default to the first sprite
        }



        logic = GameObject.FindGameObjectWithTag("Logic").GetComponent<LogicScript>();
        audioSource = GetComponent<AudioSource>();

        // Adjust flabStrength based on difficulty
      /*  if (GameManager.Instance.currentDifficulty == GameManager.Difficulty.Hard)
        {
            flabStrength = 15f; // Increase flab strength for harder difficulty
        }*/
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space) && birdIsAlive)
        {
            myRigidbody.linearVelocity = Vector2.up * flabStrength;
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (birdIsAlive)
        {
            audioSource.PlayOneShot(collisionSound);
            birdIsAlive = false;
            logic.gameOver(); // Ensure this triggers correctly
        }
    }
}