using UnityEngine;
using UnityEngine.SceneManagement; // For loading scenes

public class StartMenu : MonoBehaviour
{
    public GameObject levelSelectionPanel; // Reference to the Level Selection Panel  
    public GameObject ShopPanel;

    void Start()
    {
        levelSelectionPanel.SetActive(false); // Hide the panel initially
        ShopPanel.SetActive(false); // Hide the panel initially

    }

    // Show the level selection panel when "Select Level" is clicked
    public void ShowLevelSelection()
    {
        levelSelectionPanel.SetActive(true);
        

    }

    public void ShopPanell()
    {
        ShopPanel.SetActive(true);

    }

    // Set the difficulty to Easy
    public void SetEasyLevel()
    {
        GameManager.Instance.SetDifficulty("Easy"); // Call the GameManager to set difficulty
        levelSelectionPanel.SetActive(false); // Hide the panel after selection
    }

    // Set the difficulty to Hard
    public void SetHardLevel()
    {
        GameManager.Instance.SetDifficulty("Hard"); // Call the GameManager to set difficulty
        levelSelectionPanel.SetActive(false); // Hide the panel after selection
    }

    // Load the game scene when "Play" is clicked
    public void PlayGame()
    {
        SceneManager.LoadScene("MainGame"); // Replace "MainGame" with your actual game scene name
    }
}